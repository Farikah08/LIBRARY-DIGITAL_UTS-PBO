import { describe, it, expect, beforeEach } from "vitest";
import { Library, Book, Magazine, DigitalBook, Member } from "../src/library.js";

// ── Helpers ────────────────────────────────────────────────────

function daysAgo(n: number): Date {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d;
}

function setupBaseLibrary(): Library {
  const lib = new Library("Perpustakaan UDINUS");
  lib.addItem(new Book("BK-001", "Clean Code", 2008, "Robert C. Martin", 3));
  lib.addItem(new Book("BK-002", "The Pragmatic Programmer", 1999, "David Thomas", 1));
  lib.addItem(new Magazine("MG-001", "National Geographic", 2024, "Edisi 202", "NGS"));
  lib.addItem(new DigitalBook("DG-001", "TypeScript Deep Dive", 2023, "Basarat Ali", "https://basarat.gitbook.io/typescript"));
  lib.registerMember(new Member("MB-001", "Andi Saputra", "andi@students.udinus.ac.id"));
  lib.registerMember(new Member("MB-002", "Budi Santoso", "budi@students.udinus.ac.id"));
  lib.registerMember(new Member("MB-003", "Citra Dewi", "citra@students.udinus.ac.id"));
  return lib;
}

// ── Alur 1: Manajemen Koleksi & Anggota (15%) ─────────────────

describe("Alur 1 — Manajemen Koleksi & Anggota", () => {
  let lib: Library;

  beforeEach(() => {
    lib = setupBaseLibrary();
  });

  it("menyimpan semua item yang ditambahkan", () => {
    expect(lib.findItem("BK-001")).toBeDefined();
    expect(lib.findItem("BK-002")).toBeDefined();
    expect(lib.findItem("MG-001")).toBeDefined();
    expect(lib.findItem("DG-001")).toBeDefined();
  });

  it("menyimpan semua anggota yang didaftarkan", () => {
    expect(lib.findMember("MB-001")).toBeDefined();
    expect(lib.findMember("MB-002")).toBeDefined();
    expect(lib.findMember("MB-003")).toBeDefined();
  });

  it("menolak item dengan ID duplikat", () => {
    expect(() => lib.addItem(new Book("BK-001", "Dup", 2020, "X", 1))).toThrow();
  });

  it("menolak anggota dengan ID duplikat", () => {
    expect(() => lib.registerMember(new Member("MB-001", "Dup", "dup@x.com"))).toThrow();
  });

  it("getCatalogSummary mengembalikan total dan breakdown yang benar", () => {
    const s = lib.getCatalogSummary();
    expect(s.total).toBe(4);
    expect(s.byCategory.get("book")).toBe(2);
    expect(s.byCategory.get("magazine")).toBe(1);
    expect(s.byCategory.get("digital")).toBe(1);
  });

  it("item memiliki properti dasar yang benar", () => {
    const book = lib.findItem("BK-001")!;
    expect(book.itemId).toBe("BK-001");
    expect(book.title).toBe("Clean Code");
    expect(book.year).toBe(2008);
  });

  it("anggota memiliki properti dasar yang benar", () => {
    const member = lib.findMember("MB-001")!;
    expect(member.memberId).toBe("MB-001");
    expect(member.name).toBe("Andi Saputra");
    expect(member.email).toBe("andi@students.udinus.ac.id");
  });
});

// ── Alur 2: Peminjaman Normal (15%) ────────────────────────────

describe("Alur 2 — Peminjaman Normal", () => {
  let lib: Library;

  beforeEach(() => {
    lib = setupBaseLibrary();
  });

  it("meminjam buku berhasil dan menghasilkan LoanRecord", () => {
    const loan = lib.borrowItem("MB-001", "BK-001");
    expect(loan).toBeDefined();
    expect(loan.loanId).toBe("LN-0001");
    expect(loan.memberId).toBe("MB-001");
    expect(loan.itemId).toBe("BK-001");
  });

  it("ID transaksi berurutan", () => {
    const l1 = lib.borrowItem("MB-001", "BK-001");
    const l2 = lib.borrowItem("MB-002", "BK-001");
    const l3 = lib.borrowItem("MB-003", "MG-001");
    expect(l1.loanId).toBe("LN-0001");
    expect(l2.loanId).toBe("LN-0002");
    expect(l3.loanId).toBe("LN-0003");
  });

  it("stok berkurang setelah peminjaman", () => {
    lib.borrowItem("MB-001", "BK-001");
    const book = lib.findItem("BK-001") as Book;
    expect(book.availableCopies).toBe(2);
  });

  it("beberapa anggota bisa meminjam buku yang sama selama stok tersedia", () => {
    lib.borrowItem("MB-001", "BK-001");
    lib.borrowItem("MB-002", "BK-001");
    const book = lib.findItem("BK-001") as Book;
    expect(book.availableCopies).toBe(1);
  });

  it("meminjam majalah berhasil", () => {
    const loan = lib.borrowItem("MB-001", "MG-001");
    expect(loan.loanId).toBe("LN-0001");
  });

  it("borrowDate tercatat di LoanRecord", () => {
    const loan = lib.borrowItem("MB-001", "BK-001");
    expect(loan.borrowDate).toBeInstanceOf(Date);
  });
});

// ── Alur 3: Penolakan Peminjaman (20%) ─────────────────────────

describe("Alur 3 — Penolakan Peminjaman", () => {
  let lib: Library;

  beforeEach(() => {
    lib = setupBaseLibrary();
  });

  it("3a — menolak jika stok habis", () => {
    lib.borrowItem("MB-001", "BK-001");
    lib.borrowItem("MB-002", "BK-001");
    lib.borrowItem("MB-003", "BK-001"); // stok 0
    expect(() => lib.borrowItem("MB-001", "BK-001")).toThrow(/tidak tersedia|stok habis/i);
  });

  it("3a — menolak meminjam majalah yang sudah dipinjam orang lain", () => {
    lib.borrowItem("MB-001", "MG-001");
    expect(() => lib.borrowItem("MB-002", "MG-001")).toThrow(/tidak tersedia|stok habis/i);
  });

  it("3b — menolak jika anggota sudah punya 3 pinjaman aktif", () => {
    lib.borrowItem("MB-001", "BK-001");
    lib.borrowItem("MB-001", "BK-001"); // BK-001 punya 3 eksemplar
    lib.addItem(new Magazine("MG-002", "Kompas", 2024, "Edisi 1", "KG"));
    lib.borrowItem("MB-001", "MG-002");
    // Andi sekarang punya 3 pinjaman aktif
    lib.addItem(new Book("BK-003", "Refactoring", 2018, "Fowler", 2));
    expect(() => lib.borrowItem("MB-001", "BK-003")).toThrow(/batas pinjam/i);
  });

  it("3c — menolak peminjaman buku digital", () => {
    expect(() => lib.borrowItem("MB-001", "DG-001")).toThrow(/tidak dapat dipinjam|buku digital/i);
  });

  it("3d — menolak jika ID anggota tidak ditemukan", () => {
    expect(() => lib.borrowItem("MB-999", "BK-001")).toThrow(/MB-999/);
  });

  it("3d — menolak jika ID item tidak ditemukan", () => {
    expect(() => lib.borrowItem("MB-001", "BK-999")).toThrow(/BK-999/);
  });
});

// ── Alur 4: Pengembalian & Denda (20%) ─────────────────────────

describe("Alur 4 — Pengembalian & Denda", () => {
  let lib: Library;

  beforeEach(() => {
    lib = setupBaseLibrary();
  });

  it("pengembalian berhasil memperbarui stok", () => {
    lib.borrowItem("MB-001", "BK-001");
    lib.returnItem("MB-001", "BK-001");
    const book = lib.findItem("BK-001") as Book;
    expect(book.availableCopies).toBe(3);
  });

  it("pengembalian berhasil menghapus pinjaman aktif anggota", () => {
    lib.borrowItem("MB-001", "BK-001");
    lib.returnItem("MB-001", "BK-001");
    const active = lib.getActiveLoans().filter((l) => l.memberId === "MB-001");
    expect(active.length).toBe(0);
  });

  it("returnItem mengembalikan LoanRecord", () => {
    lib.borrowItem("MB-001", "BK-001");
    const ret = lib.returnItem("MB-001", "BK-001");
    expect(ret).toBeDefined();
    expect(ret.memberId).toBe("MB-001");
    expect(ret.itemId).toBe("BK-001");
  });

  it("menolak jika anggota mencoba mengembalikan item yang bukan miliknya", () => {
    lib.borrowItem("MB-001", "MG-001");
    expect(() => lib.returnItem("MB-002", "MG-001")).toThrow(/tidak memiliki pinjaman/i);
  });

  it("denda = 0 jika dikembalikan tepat waktu", () => {
    lib.borrowItem("MB-001", "BK-001");
    const ret = lib.returnItem("MB-001", "BK-001", 7, 1000);
    expect(ret.fine).toBe(0);
  });

  it("denda dihitung per hari keterlambatan", () => {
    lib.borrowItem("MB-001", "BK-001", daysAgo(10));
    const ret = lib.returnItem("MB-001", "BK-001", 7, 1000);
    expect(ret.fine).toBe(3000); // 3 hari terlambat × Rp 1000
  });

  it("denda tidak negatif jika dikembalikan lebih awal", () => {
    lib.borrowItem("MB-001", "BK-001", daysAgo(3));
    const ret = lib.returnItem("MB-001", "BK-001", 7, 1000);
    expect(ret.fine).toBe(0);
  });

  it("majalah kembali tersedia setelah dikembalikan", () => {
    lib.borrowItem("MB-001", "MG-001");
    lib.returnItem("MB-001", "MG-001");
    // sekarang anggota lain bisa meminjam
    expect(() => lib.borrowItem("MB-002", "MG-001")).not.toThrow();
  });

  it("returnItem — default dueDays=7, ratePerDay=1000 jika tidak diisi", () => {
    lib.borrowItem("MB-001", "BK-001", daysAgo(10));
    const ret = lib.returnItem("MB-001", "BK-001");
    expect(ret.fine).toBe(3000);
  });
});

// ── Alur 5: Pencarian & Filter (15%) ───────────────────────────

describe("Alur 5 — Pencarian & Filter", () => {
  let lib: Library;

  beforeEach(() => {
    lib = setupBaseLibrary();
  });

  it("searchItems menemukan item berdasarkan keyword case-insensitive", () => {
    const results = lib.searchItems("code");
    expect(results.some((i) => i.title === "Clean Code")).toBe(true);
  });

  it("searchItems 'CODE' menghasilkan hasil sama dengan 'code'", () => {
    const r1 = lib.searchItems("code");
    const r2 = lib.searchItems("CODE");
    expect(r1.map((i) => i.itemId).sort()).toEqual(r2.map((i) => i.itemId).sort());
  });

  it("searchItems mengembalikan array kosong jika tidak ada hasil", () => {
    const results = lib.searchItems("xyznotfound123");
    expect(results).toHaveLength(0);
  });

  it("filter berdasarkan kategori digital", () => {
    const results = lib.searchItems("", "digital");
    expect(results.every((i) => i.getCategory() === "digital")).toBe(true);
    expect(results.some((i) => i.itemId === "DG-001")).toBe(true);
  });

  it("filter berdasarkan kategori book", () => {
    const results = lib.searchItems("", "book");
    expect(results.every((i) => i.getCategory() === "book")).toBe(true);
    expect(results).toHaveLength(2);
  });

  it("pengurutan tidak mengubah data asli di sistem", () => {
    const before = lib.searchItems("").map((i) => i.itemId);
    // sort by year descending
    lib.searchItems("").sort((a, b) => b.year - a.year);
    const after = lib.searchItems("").map((i) => i.itemId);
    expect(before).toEqual(after);
  });
});

// ── Alur 6: Laporan (15%) ──────────────────────────────────────

describe("Alur 6 — Laporan", () => {
  let lib: Library;

  beforeEach(() => {
    lib = setupBaseLibrary();
  });

  it("6a — getOverdueLoans mengembalikan pinjaman yang melewati batas waktu", () => {
    lib.borrowItem("MB-001", "BK-001", daysAgo(10));
    lib.borrowItem("MB-002", "BK-001", daysAgo(3));
    const overdue = lib.getOverdueLoans(7);
    expect(overdue.some((l) => l.memberId === "MB-001")).toBe(true);
    expect(overdue.some((l) => l.memberId === "MB-002")).toBe(false);
  });

  it("6a — pinjaman yang sudah dikembalikan tidak muncul di overdue", () => {
    lib.borrowItem("MB-001", "BK-001", daysAgo(10));
    lib.returnItem("MB-001", "BK-001");
    const overdue = lib.getOverdueLoans(7);
    expect(overdue.some((l) => l.memberId === "MB-001")).toBe(false);
  });

  it("6b — getMostBorrowedItems mengembalikan N item teratas", () => {
    lib.borrowItem("MB-001", "BK-001", daysAgo(1));
    lib.borrowItem("MB-002", "BK-001", daysAgo(1));
    lib.borrowItem("MB-003", "MG-001", daysAgo(1));
    lib.returnItem("MB-001", "BK-001");
    lib.returnItem("MB-002", "BK-001");

    const top = lib.getMostBorrowedItems(1);
    expect(top[0]?.itemId).toBe("BK-001");
    expect(top[0]?.borrowCount).toBe(2);
  });

  it("6b — buku digital tidak masuk dalam getMostBorrowedItems", () => {
    const top = lib.getMostBorrowedItems(10);
    expect(top.every((r) => r.itemId !== "DG-001")).toBe(true);
  });

  it("6c — getMemberStats mengembalikan data yang benar", () => {
    lib.borrowItem("MB-001", "BK-001", daysAgo(1));
    lib.borrowItem("MB-001", "BK-001", daysAgo(1)); // BK-001 punya 3 eksemplar
    lib.returnItem("MB-001", "BK-001"); // kembalikan yang pertama

    const stats = lib.getMemberStats("MB-001");
    expect(stats.memberId).toBe("MB-001");
    expect(stats.name).toBe("Andi Saputra");
    expect(stats.totalBorrowed).toBe(2);
    expect(stats.activeLoans).toBe(1);
  });

  it("6c — totalFine di MemberStats menghitung denda aktif yang overdue", () => {
    lib.borrowItem("MB-001", "BK-001", daysAgo(10));
    const stats = lib.getMemberStats("MB-001", 7, 1000);
    expect(stats.totalFine).toBe(3000);
  });

  it("6d — getTotalFines menjumlahkan denda semua pinjaman aktif yang overdue", () => {
    lib.borrowItem("MB-001", "BK-001", daysAgo(10)); // 3 hari terlambat
    lib.borrowItem("MB-002", "BK-001", daysAgo(9)); // 2 hari terlambat
    lib.borrowItem("MB-003", "MG-001", daysAgo(2)); // belum terlambat
    const total = lib.getTotalFines(7, 1000);
    expect(total).toBe(5000); // (3 + 2) × 1000
  });

  it("getActiveLoans mengembalikan semua pinjaman aktif", () => {
    lib.borrowItem("MB-001", "BK-001");
    lib.borrowItem("MB-002", "MG-001");
    lib.returnItem("MB-001", "BK-001");
    const active = lib.getActiveLoans();
    expect(active).toHaveLength(1);
    expect(active[0]?.memberId).toBe("MB-002");
  });
});
