// ==================
// TYPES
// ==================

export type ItemCategory = "book" | "magazine" | "digital";

export type MemberStats = {
  memberId: string;
  name: string;
  totalBorrowed: number;
  activeLoans: number;
  totalFine: number;
};

export type CatalogSummary = {
  total: number;
  byCategory: Map<ItemCategory, number>;
};

// ==================
// ITEM BASE
// ==================

export abstract class Item {
  constructor(
    public itemId: string,
    public title: string,
    public year: number
  ) {}

  abstract getCategory(): ItemCategory;
}

// ==================
// ITEMS
// ==================

export class Book extends Item {
  constructor(
    itemId: string,
    title: string,
    year: number,
    public author: string,
    public stock: number
  ) {
    super(itemId, title, year);
  }

  getCategory(): ItemCategory {
    return "book";
  }
}

export class Magazine extends Item {
  public stock: number = 1;

  constructor(
    itemId: string,
    title: string,
    year: number,
    public issue: string,
    public publisher: string
  ) {
    super(itemId, title, year);
  }

  getCategory(): ItemCategory {
    return "magazine";
  }
}

export class DigitalBook extends Item {
  constructor(
    itemId: string,
    title: string,
    year: number,
    public author: string,
    public url: string
  ) {
    super(itemId, title, year);
  }

  getCategory(): ItemCategory {
    return "digital";
  }
}

// ==================
// MEMBER
// ==================

export class Member {
  constructor(
    public memberId: string,
    public name: string,
    public email: string
  ) {}
}

// ==================
// LOAN
// ==================

export class LoanRecord {
  constructor(
    public loanId: string,
    public memberId: string,
    public itemId: string,
    public borrowDate: Date,
    public returned: boolean = false,
    public returnDate?: Date
  ) {}
}

// ==================
// LIBRARY
// ==================

export class Library {
  private items = new Map<string, Item>();
  private members = new Map<string, Member>();
  private loans: LoanRecord[] = [];
  private loanCounter = 1;

  constructor(public name: string) {}

  // ==================
  // BASIC
  // ==================

  addItem(item: Item) {
    if (this.items.has(item.itemId)) {
      throw new Error(`Item dengan ID '${item.itemId}' sudah ada.`);
    }
    this.items.set(item.itemId, item);
  }

  registerMember(member: Member) {
    if (this.members.has(member.memberId)) {
      throw new Error(`Member dengan ID '${member.memberId}' sudah ada.`);
    }
    this.members.set(member.memberId, member);
  }

  findItem(itemId: string): Item | undefined {
    return this.items.get(itemId);
  }

  findMember(memberId: string): Member | undefined {
    return this.members.get(memberId);
  }

  // ==================
  // SEARCH & SUMMARY
  // ==================

  searchItems(keyword: string): Item[] {
    const lower = keyword.toLowerCase();
    return Array.from(this.items.values()).filter(item =>
      item.title.toLowerCase().includes(lower)
    );
  }

  getCatalogSummary(): CatalogSummary {
    const byCategory = new Map<ItemCategory, number>();

    for (const item of this.items.values()) {
      const cat = item.getCategory();
      byCategory.set(cat, (byCategory.get(cat) || 0) + 1);
    }

    return {
      total: this.items.size,
      byCategory
    };
  }

  // ==================
  // BORROW
  // ==================

  borrowItem(
    memberId: string,
    itemId: string,
    borrowDate: Date = new Date()
  ): LoanRecord {
    const member = this.members.get(memberId);
    if (!member) {
      throw new Error(`Anggota dengan ID '${memberId}' tidak ditemukan.`);
    }

    const item = this.items.get(itemId);
    if (!item) {
      throw new Error(`Item dengan ID '${itemId}' tidak ditemukan.`);
    }

    // ❌ digital tidak bisa dipinjam
    if (item instanceof DigitalBook) {
      throw new Error(
        "Item ini tidak dapat dipinjam. Buku digital dapat diakses langsung tanpa peminjaman."
      );
    }

    // ❌ cek limit 3
    const activeLoans = this.loans.filter(
      l => l.memberId === memberId && !l.returned
    );
    if (activeLoans.length >= 3) {
      throw new Error(
        "Tidak dapat meminjam, batas pinjam aktif (3 item) sudah tercapai."
      );
    }

    // ❌ cek stok
    if ((item as any).stock <= 0) {
      throw new Error("Item tidak tersedia, stok habis.");
    }

    // buat ID
    const loanId = `LN-${String(this.loanCounter).padStart(4, "0")}`;
    this.loanCounter++;

    const loan = new LoanRecord(loanId, memberId, itemId, borrowDate);
    this.loans.push(loan);

    // kurangi stok
    (item as any).stock--;

    return loan;
  }

  // ==================
  // RETURN
  // ==================

  returnItem(memberId: string, itemId: string): LoanRecord {
    const loan = this.loans.find(
      l =>
        l.memberId === memberId &&
        l.itemId === itemId &&
        !l.returned
    );

    if (!loan) {
      throw new Error(
        "Anggota ini tidak memiliki pinjaman aktif untuk item tersebut."
      );
    }

    loan.returned = true;
    loan.returnDate = new Date();

    const item = this.items.get(itemId);
    if (item && !(item instanceof DigitalBook)) {
      (item as any).stock++;
    }

    return loan;
  }

  // ==================
  // LOANS
  // ==================

  getActiveLoans(): LoanRecord[] {
    return this.loans.filter(l => !l.returned);
  }

  getOverdueLoans(dueDays: number): LoanRecord[] {
    const now = new Date();

    return this.getActiveLoans().filter(l => {
      const diff =
        (now.getTime() - l.borrowDate.getTime()) /
        (1000 * 60 * 60 * 24);
      return diff > dueDays;
    });
  }

  // ==================
  // REPORT
  // ==================

  getMemberStats(memberId: string): MemberStats {
    const member = this.members.get(memberId);
    if (!member) {
      throw new Error(`Member dengan ID '${memberId}' tidak ditemukan.`);
    }

    const memberLoans = this.loans.filter(l => l.memberId === memberId);

    const totalBorrowed = memberLoans.length;
    const activeLoans = memberLoans.filter(l => !l.returned).length;

    const overdueLoans = this.getOverdueLoans(7).filter(
      l => l.memberId === memberId
    );

    let totalFine = 0;

    const now = new Date();

    for (const loan of overdueLoans) {
      const days =
        (now.getTime() - loan.borrowDate.getTime()) /
        (1000 * 60 * 60 * 24);
      const lateDays = Math.floor(days - 7);
      totalFine += lateDays * 1000;
    }

    return {
      memberId,
      name: member.name,
      totalBorrowed,
      activeLoans,
      totalFine
    };
  }

  getMostBorrowedItems(topN: number): Item[] {
    const countMap = new Map<string, number>();

    for (const loan of this.loans) {
      const item = this.items.get(loan.itemId);
      if (item instanceof DigitalBook) continue;

      countMap.set(
        loan.itemId,
        (countMap.get(loan.itemId) || 0) + 1
      );
    }

    const sorted = Array.from(countMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, topN);

    return sorted.map(([itemId]) => this.items.get(itemId)!);
  }

  getTotalFines(dueDays: number, ratePerDay: number): number {
    const overdueLoans = this.getOverdueLoans(dueDays);
    const now = new Date();

    let total = 0;

    for (const loan of overdueLoans) {
      const days =
        (now.getTime() - loan.borrowDate.getTime()) /
        (1000 * 60 * 60 * 24);

      const lateDays = Math.floor(days - dueDays);
      total += lateDays * ratePerDay;
    }

    return total;
  }
}