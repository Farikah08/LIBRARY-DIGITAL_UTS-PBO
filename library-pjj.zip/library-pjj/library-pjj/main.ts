import { Library, Book, Magazine, DigitalBook, Member } from "./src/library.js";

const lib = new Library("Perpustakaan UDINUS");

// ── Alur 1: Setup ──────────────────────────────────────────────
console.log("=== Alur 1: Setup Sistem ===\n");

lib.addItem(new Book("BK-001", "Clean Code", 2008, "Robert C. Martin", 3));
lib.addItem(new Book("BK-002", "The Pragmatic Programmer", 1999, "David Thomas", 1));
lib.addItem(new Magazine("MG-001", "National Geographic", 2024, "Edisi 202", "NGS"));
lib.addItem(new DigitalBook("DG-001", "TypeScript Deep Dive", 2023, "Basarat Ali", "https://basarat.gitbook.io/typescript"));

lib.registerMember(new Member("MB-001", "Andi Saputra", "andi@students.udinus.ac.id"));
lib.registerMember(new Member("MB-002", "Budi Santoso", "budi@students.udinus.ac.id"));
lib.registerMember(new Member("MB-003", "Citra Dewi", "citra@students.udinus.ac.id"));

// Duplicate ID test
try {
  lib.addItem(new Book("BK-001", "Duplicate", 2020, "Someone", 1));
} catch (e) {
  console.log("Expected error:", (e as Error).message);
}

try {
  lib.registerMember(new Member("MB-001", "Duplicate", "dup@test.com"));
} catch (e) {
  console.log("Expected error:", (e as Error).message);
}

const summary = lib.getCatalogSummary();
console.log(`\nKatalog: ${summary.total} item total`);
console.log(`  book: ${summary.byCategory.get("book")}`);
console.log(`  magazine: ${summary.byCategory.get("magazine")}`);
console.log(`  digital: ${summary.byCategory.get("digital")}`);

// ── Alur 2: Peminjaman Berhasil ─────────────────────────────────
console.log("\n=== Alur 2: Peminjaman Berhasil ===\n");

const loan1 = lib.borrowItem("MB-001", "BK-001");
console.log(`${loan1.loanId} - Andi meminjam Clean Code`);

const loan2 = lib.borrowItem("MB-002", "BK-001");
console.log(`${loan2.loanId} - Budi meminjam Clean Code`);

const loan3 = lib.borrowItem("MB-003", "MG-001");
console.log(`${loan3.loanId} - Citra meminjam National Geographic`);

// ── Alur 3: Penolakan ──────────────────────────────────────────
console.log("\n=== Alur 3: Penolakan ===\n");

// 3a: Stok habis
const loan4 = lib.borrowItem("MB-001", "BK-001"); // Andi pinjam lagi, stok jadi 0
console.log(`${loan4.loanId} - Andi meminjam Clean Code lagi (stok jadi 0)`);

try {
  lib.borrowItem("MB-002", "BK-001");
} catch (e) {
  console.log("3a - Stok habis:", (e as Error).message);
}

// 3b: Batas pinjam (Andi sudah 2, tambah 1 lagi biar 3, lalu coba ke-4)
const loan5 = lib.borrowItem("MB-001", "BK-002");
console.log(`${loan5.loanId} - Andi meminjam The Pragmatic Programmer (total 3 aktif)`);

try {
  lib.borrowItem("MB-001", "MG-001"); // MG-001 sudah dipinjam Citra, tapi test batas dulu
} catch (e) {
  console.log("3b - Batas pinjam:", (e as Error).message);
}

// 3c: Buku digital
try {
  lib.borrowItem("MB-002", "DG-001");
} catch (e) {
  console.log("3c - Digital:", (e as Error).message);
}

// 3d: ID tidak ditemukan
try {
  lib.borrowItem("MB-999", "BK-001");
} catch (e) {
  console.log("3d - Member not found:", (e as Error).message);
}

try {
  lib.borrowItem("MB-002", "BK-999");
} catch (e) {
  console.log("3d - Item not found:", (e as Error).message);
}

// ── Alur 4: Pengembalian & Denda ───────────────────────────────
console.log("\n=== Alur 4: Pengembalian & Denda ===\n");

// Andi kembalikan Clean Code (loan1)
const ret1 = lib.returnItem("MB-001", "BK-001");
console.log(`Andi mengembalikan Clean Code, denda: Rp ${ret1.fine ?? 0}`);

// Budi coba kembalikan majalah Citra
try {
  lib.returnItem("MB-002", "MG-001");
} catch (e) {
  console.log("Budi coba kembalikan milik Citra:", (e as Error).message);
}

// Citra kembalikan majalah dengan simulasi terlambat 10 hari
const tenDaysAgo = new Date();
tenDaysAgo.setDate(tenDaysAgo.getDate() - 10);

// Untuk demo, kita perlu pinjam lagi dengan tanggal custom
// (loan3 sudah ada, tapi borrowDate-nya hari ini, jadi kita simulasi via returnItem dengan dueDays=7)
const ret3 = lib.returnItem("MB-003", "MG-001", 7, 1000);
console.log(`Citra mengembalikan majalah, denda: Rp ${ret3.fine ?? 0}`);
// Denda = 0 karena borrowDate = hari ini, belum melewati 7 hari
// Untuk test denda, borrowItem dengan tanggal custom dipakai di test

// Demo borrowItem dengan tanggal custom
lib.addItem(new Magazine("MG-002", "Tempo", 2024, "Edisi 100", "Tempo"));
lib.registerMember(new Member("MB-004", "Dani", "dani@test.com"));
const customDate = new Date();
customDate.setDate(customDate.getDate() - 10);
lib.borrowItem("MB-004", "MG-002", customDate);
const ret4 = lib.returnItem("MB-004", "MG-002", 7, 1000);
console.log(`Dani terlambat 3 hari, denda: Rp ${ret4.fine ?? 0}`); // Expected: 3000

// ── Alur 5: Pencarian ──────────────────────────────────────────
console.log("\n=== Alur 5: Pencarian & Filter ===\n");

const codeResults = lib.searchItems("code");
console.log(`Pencarian "code": ${codeResults.map((i) => i.title).join(", ")}`);

const digitalItems = lib.searchItems("", "digital");
console.log(`Filter digital: ${digitalItems.map((i) => i.title).join(", ")}`);

// ── Alur 6: Laporan ────────────────────────────────────────────
console.log("\n=== Alur 6: Laporan ===\n");

const overdue = lib.getOverdueLoans(7);
console.log(`Pinjaman overdue: ${overdue.length} item`);

const top3 = lib.getMostBorrowedItems(3);
console.log("Top 3 paling sering dipinjam:");
top3.forEach((r, i) => console.log(`  ${i + 1}. ${r.title} (${r.borrowCount}x)`));

const andiStats = lib.getMemberStats("MB-001");
console.log(`\nStatistik Andi:`);
console.log(`  Total pernah dipinjam: ${andiStats.totalBorrowed}`);
console.log(`  Aktif saat ini: ${andiStats.activeLoans}`);
console.log(`  Total denda: Rp ${andiStats.totalFine}`);

const totalFines = lib.getTotalFines(7, 1000);
console.log(`\nTotal denda beredar: Rp ${totalFines}`);
