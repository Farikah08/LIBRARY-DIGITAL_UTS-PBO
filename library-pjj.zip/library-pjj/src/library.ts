// ── Types ──────────────────────────────────────────────────────

export type ItemCategory = "book" | "magazine" | "digital";

export type MemberStats = {
  memberId: string;
  name: string;
  totalBorrowed: number;
  activeLoans: number;
  totalFine: number;
};

export type CatalogSummary = {
  total: number;
  byCategory: Map<ItemCategory, number>;
};

// ── LoanRecord ─────────────────────────────────────────────────

export class LoanRecord {
  loanId: string;
  memberId: string;
  itemId: string;
  borrowDate: Date;
  returnDate: Date | null = null;
  fine: number = 0;

  constructor(
    loanId: string,
    memberId: string,
    itemId: string,
    borrowDate: Date,
  ) {
    this.loanId = loanId;
    this.memberId = memberId;
    this.itemId = itemId;
    this.borrowDate = borrowDate;
  }

  isActive(): boolean {
    return this.returnDate === null;
  }

  calculateFine(dueDays: number, ratePerDay: number): number {
    const now = new Date();
    const dueDate = new Date(this.borrowDate);
    dueDate.setDate(dueDate.getDate() + dueDays);
    const diffMs = now.getTime() - dueDate.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    return Math.max(0, diffDays) * ratePerDay;
  }
}

// ── Abstract LibraryItem ───────────────────────────────────────

export abstract class LibraryItem {
  itemId: string;
  title: string;
  year: number;

  constructor(itemId: string, title: string, year: number) {
    this.itemId = itemId;
    this.title = title;
    this.year = year;
  }

  abstract getCategory(): ItemCategory;
  abstract getDescription(): string;
  abstract canBorrow(): boolean;
  abstract checkoutCopy(): void;
  abstract returnCopy(): void;
  abstract isAvailable(): boolean;
}

// ── Book ───────────────────────────────────────────────────────

export class Book extends LibraryItem {
  author: string;
  totalCopies: number;
  availableCopies: number;

  constructor(
    itemId: string,
    title: string,
    year: number,
    author: string,
    totalCopies: number,
  ) {
    super(itemId, title, year);
    this.author = author;
    this.totalCopies = totalCopies;
    this.availableCopies = totalCopies;
  }

  getCategory(): ItemCategory {
    return "book";
  }

  getDescription(): string {
    return `${this.title} by ${this.author} (${this.year}), ${this.availableCopies}/${this.totalCopies} available`;
  }

  canBorrow(): boolean {
    return true;
  }

  isAvailable(): boolean {
    return this.availableCopies > 0;
  }

  checkoutCopy(): void {
    if (this.availableCopies <= 0) throw new Error("No copies available");
    this.availableCopies--;
  }

  returnCopy(): void {
    this.availableCopies++;
  }
}

// ── Magazine ───────────────────────────────────────────────────

export class Magazine extends LibraryItem {
  edition: string;
  publisher: string;
  private borrowed: boolean = false;

  constructor(
    itemId: string,
    title: string,
    year: number,
    edition: string,
    publisher: string,
  ) {
    super(itemId, title, year);
    this.edition = edition;
    this.publisher = publisher;
  }

  getCategory(): ItemCategory {
    return "magazine";
  }

  getDescription(): string {
    return `${this.title} ${this.edition}, ${this.publisher} (${this.year})`;
  }

  canBorrow(): boolean {
    return true;
  }

  isAvailable(): boolean {
    return !this.borrowed;
  }

  checkoutCopy(): void {
    if (this.borrowed) throw new Error("Magazine is already borrowed");
    this.borrowed = true;
  }

  returnCopy(): void {
    this.borrowed = false;
  }
}

// ── DigitalBook ────────────────────────────────────────────────

export class DigitalBook extends LibraryItem {
  author: string;
  url: string;

  constructor(
    itemId: string,
    title: string,
    year: number,
    author: string,
    url: string,
  ) {
    super(itemId, title, year);
    this.author = author;
    this.url = url;
  }

  getCategory(): ItemCategory {
    return "digital";
  }

  getDescription(): string {
    return `${this.title} by ${this.author} (${this.year}), available at ${this.url}`;
  }

  canBorrow(): boolean {
    return false;
  }

  isAvailable(): boolean {
    return true;
  }

  checkoutCopy(): void {
    throw new Error(
      "Item ini tidak dapat dipinjam. Buku digital dapat diakses langsung tanpa peminjaman.",
    );
  }

  returnCopy(): void {
    // no-op
  }
}

// ── Member ─────────────────────────────────────────────────────

export class Member {
  memberId: string;
  name: string;
  email: string;

  constructor(memberId: string, name: string, email: string) {
    this.memberId = memberId;
    this.name = name;
    this.email = email;
  }
}

// ── Library ────────────────────────────────────────────────────

export class Library {
  name: string;
  private items: Map<string, LibraryItem> = new Map();
  private members: Map<string, Member> = new Map();
  private loans: LoanRecord[] = [];
  private loanCounter: number = 0;

  constructor(name: string) {
    this.name = name;
  }

  // ── Collection management ──────────────────────────────────

  addItem(item: LibraryItem): void {
    if (this.items.has(item.itemId)) {
      throw new Error(`Item dengan ID '${item.itemId}' sudah ada di sistem.`);
    }
    this.items.set(item.itemId, item);
  }

  registerMember(member: Member): void {
    if (this.members.has(member.memberId)) {
      throw new Error(
        `Anggota dengan ID '${member.memberId}' sudah terdaftar.`,
      );
    }
    this.members.set(member.memberId, member);
  }

  findItem(itemId: string): LibraryItem | undefined {
    return this.items.get(itemId);
  }

  findMember(memberId: string): Member | undefined {
    return this.members.get(memberId);
  }

  getCatalogSummary(): CatalogSummary {
    const byCategory = new Map<ItemCategory, number>();
    for (const item of this.items.values()) {
      const cat = item.getCategory();
      byCategory.set(cat, (byCategory.get(cat) ?? 0) + 1);
    }
    return { total: this.items.size, byCategory };
  }

  // ── Borrowing ──────────────────────────────────────────────

  borrowItem(memberId: string, itemId: string, borrowDate?: Date): LoanRecord {
    const member = this.members.get(memberId);
    if (!member)
      throw new Error(`Anggota dengan ID '${memberId}' tidak ditemukan.`);

    const item = this.items.get(itemId);
    if (!item) throw new Error(`Item dengan ID '${itemId}' tidak ditemukan.`);

    if (!item.canBorrow()) {
      throw new Error(
        "Item ini tidak dapat dipinjam. Buku digital dapat diakses langsung tanpa peminjaman.",
      );
    }

    if (!item.isAvailable()) {
      throw new Error("Item tidak tersedia, stok habis.");
    }

    const activeCount = this.loans.filter(
      (l) => l.memberId === memberId && l.isActive(),
    ).length;
    if (activeCount >= 3) {
      throw new Error(
        "Tidak dapat meminjam, batas pinjam aktif (3 item) sudah tercapai.",
      );
    }

    item.checkoutCopy();

    this.loanCounter++;
    const loanId = `LN-${String(this.loanCounter).padStart(4, "0")}`;
    const loan = new LoanRecord(
      loanId,
      memberId,
      itemId,
      borrowDate ?? new Date(),
    );
    this.loans.push(loan);
    return loan;
  }

  // ── Returning ──────────────────────────────────────────────

  returnItem(
    memberId: string,
    itemId: string,
    dueDays: number = 7,
    ratePerDay: number = 1000,
  ): LoanRecord {
    const member = this.members.get(memberId);
    if (!member)
      throw new Error(`Anggota dengan ID '${memberId}' tidak ditemukan.`);

    const item = this.items.get(itemId);
    if (!item) throw new Error(`Item dengan ID '${itemId}' tidak ditemukan.`);

    const loan = this.loans.find(
      (l) => l.memberId === memberId && l.itemId === itemId && l.isActive(),
    );

    if (!loan) {
      throw new Error(
        `Anggota ini tidak memiliki pinjaman aktif untuk item tersebut.`,
      );
    }

    loan.returnDate = new Date();
    loan.fine = loan.calculateFine(dueDays, ratePerDay);
    item.returnCopy();

    return loan;
  }

  // ── Queries ────────────────────────────────────────────────

  getActiveLoans(): LoanRecord[] {
    return this.loans.filter((l) => l.isActive());
  }

  searchItems(keyword: string, category?: string): LibraryItem[] {
    const kw = keyword.toLowerCase();
    return Array.from(this.items.values()).filter((item) => {
      const matchesKeyword = kw === "" || item.title.toLowerCase().includes(kw);
      const matchesCategory = !category || item.getCategory() === category;
      return matchesKeyword && matchesCategory;
    });
  }

  // ── Reports ────────────────────────────────────────────────

  getOverdueLoans(dueDays: number = 7): LoanRecord[] {
    const now = new Date();
    return this.loans.filter((l) => {
      if (!l.isActive()) return false;
      const dueDate = new Date(l.borrowDate);
      dueDate.setDate(dueDate.getDate() + dueDays);
      return now > dueDate;
    });
  }

  getMostBorrowedItems(
    topN: number,
  ): { itemId: string; title: string; borrowCount: number }[] {
    const countMap = new Map<string, number>();
    for (const loan of this.loans) {
      const item = this.items.get(loan.itemId);
      if (!item || item.getCategory() === "digital") continue;
      countMap.set(loan.itemId, (countMap.get(loan.itemId) ?? 0) + 1);
    }

    return Array.from(countMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, topN)
      .map(([itemId, borrowCount]) => ({
        itemId,
        title: this.items.get(itemId)!.title,
        borrowCount,
      }));
  }

  getMemberStats(
    memberId: string,
    dueDays: number = 7,
    ratePerDay: number = 1000,
  ): MemberStats {
    const member = this.members.get(memberId);
    if (!member)
      throw new Error(`Anggota dengan ID '${memberId}' tidak ditemukan.`);

    const memberLoans = this.loans.filter((l) => l.memberId === memberId);
    const activeLoans = memberLoans.filter((l) => l.isActive());

    const totalFine = activeLoans.reduce(
      (sum, l) => sum + l.calculateFine(dueDays, ratePerDay),
      0,
    );

    return {
      memberId,
      name: member.name,
      totalBorrowed: memberLoans.length,
      activeLoans: activeLoans.length,
      totalFine,
    };
  }

  getTotalFines(dueDays: number = 7, ratePerDay: number = 1000): number {
    return this.loans
      .filter((l) => l.isActive())
      .reduce((sum, l) => sum + l.calculateFine(dueDays, ratePerDay), 0);
  }
}
